var stable = new Map();
stable.set(1, "1 is online");
stable.set(3, "3 is online")

module.exports=stable;